//
//  Tutorial1Controller.h
//  usermanual
//
//  Created by Laïla Atrmouh on 23/10/12.
//  Copyright (c) 2012 URI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Tutorial1Controller : UIViewController


- (IBAction) backToMainView;



@end
